<!--banner-->
<div class="banner-top">
	<div class="container">
		<h1>Products</h1>
		<em></em>
		<h2><a href="index.php">Home</a><label>/</label>Products</h2>
	</div>
</div>

<?php
require_once 'core/init.php';
include 'includes/head.php';
include 'includes/navigation.php';
include 'includes/headerfull.php';
// include 'includes/leftbar.php';
?>
<?php
$sql      = "SELECT * FROM products WHERE featured = 1";
$featured = $db->query($sql);
?>
<!--content-->

<div>

<!-- Main Content -->
	<div class="col-md-8">
		<div class="row">
			<h2 class="text-center">Featured</h2>

<?php while ($product = mysqli_fetch_assoc($featured)):?>
			<div class="col-md-3">
				<h4><?php echo $product['title'];?></h4>
				<img class="img-thumb" src="<?php echo $product['image'];?>" alt="<?php echo $product['title'];?>">
				<p class="list-price text-danger">List Price: <s><?php echo $product['list_price'];?></s></p>
				<p class="price">Our Price: <?php echo $product['price'];?></p>
				<button type="button" class="btn btn-sm btn-success" onclick="detailsmodal(<?php echo $product['id'];?>)">Details</button>
			</div>
<?php endwhile;?>
</div>
	</div>

<!--//content-->
</div>



<?php
$sql      = "SELECT * FROM products WHERE categories >= 13 and categories<=14 ";
$featured = $db->query($sql);
?>
<div>

<!-- Main Content -->
	<div class="col-md-8">
		<div class="row">
			<h2 class="text-center">Boy's Products</h2>

<?php while ($product = mysqli_fetch_assoc($featured)):?>
			<div class="col-md-3">
				<h4><?php echo $product['title'];?></h4>
				<img class="img-thumb" src="<?php echo $product['image'];?>" alt="<?php echo $product['title'];?>">
				<p class="list-price text-danger">List Price: <s><?php echo $product['list_price'];?></s></p>
				<p class="price">Our Price: <?php echo $product['price'];?></p>
				<button type="button" class="btn btn-sm btn-success" onclick="detailsmodal(<?php echo $product['id'];?>)">Details</button>
			</div>
<?php endwhile;?>
</div>
	</div>

<!--//content-->
</div>




<?php
$sql      = "SELECT * FROM products WHERE categories >= 5 and categories<=6 ";
$featured = $db->query($sql);
?>
<div>

<!-- Main Content -->
	<div class="col-md-8">
		<div class="row">
			<h2 class="text-center">Men's Product</h2>

<?php while ($product = mysqli_fetch_assoc($featured)):?>
			<div class="col-md-3">
				<h4><?php echo $product['title'];?></h4>
				<img class="img-thumb" src="<?php echo $product['image'];?>" alt="<?php echo $product['title'];?>">
				<p class="list-price text-danger">List Price: <s><?php echo $product['list_price'];?></s></p>
				<p class="price">Our Price: <?php echo $product['price'];?></p>
				<button type="button" class="btn btn-sm btn-success" onclick="detailsmodal(<?php echo $product['id'];?>)">Details</button>
			</div>
<?php endwhile;?>
</div>
	</div>

<!--//content-->
</div>


<?php
$sql      = "SELECT * FROM products WHERE categories = 15 ";
$featured = $db->query($sql);
?>
<div>

<!-- Main Content -->
	<div class="col-md-8">
		<div class="row">
			<h2 class="text-center">Girls'  Product</h2>

<?php while ($product = mysqli_fetch_assoc($featured)):?>
			<div class="col-md-3">
				<h4><?php echo $product['title'];?></h4>
				<img class="img-thumb" src="<?php echo $product['image'];?>" alt="<?php echo $product['title'];?>">
				<p class="list-price text-danger">List Price: <s><?php echo $product['list_price'];?></s></p>
				<p class="price">Our Price: <?php echo $product['price'];?></p>
				<button type="button" class="btn btn-sm btn-success" onclick="detailsmodal(<?php echo $product['id'];?>)">Details</button>
			</div>
<?php endwhile;?>
</div>
	</div>

<!--//content-->
</div>

<?php
$sql      = "SELECT * FROM products WHERE price>=10 and price<=20";
$featured = $db->query($sql);
?>
<div>

<!-- Main Content -->
	<div class="col-md-8">
		<div class="row">
			<h2 class="text-center">$10~$20 filter</h2>

<?php while ($product = mysqli_fetch_assoc($featured)):?>
			<div class="col-md-3">
				<h4><?php echo $product['title'];?></h4>
				<img class="img-thumb" src="<?php echo $product['image'];?>" alt="<?php echo $product['title'];?>">
				<p class="list-price text-danger">List Price: <s><?php echo $product['list_price'];?></s></p>
				<p class="price">Our Price: <?php echo $product['price'];?></p>
				<button type="button" class="btn btn-sm btn-success" onclick="detailsmodal(<?php echo $product['id'];?>)">Details</button>
			</div>
<?php endwhile;?>
</div>
	</div>

<!--//content-->
</div>







</div>












<?php
// include 'includes/rightbar.php';
// include 'includes/footer.php';
?>
