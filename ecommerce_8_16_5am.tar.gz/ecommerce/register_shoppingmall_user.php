<?php

// $conn        = mysqli_connect("localhost", "root", "0000", "Login_Test");
// $data_stream = "'".$_GET['Id']."','".$_GET['Password']."','".$_GET['Name']."','".$_GET['PhoneNum']."','".$_GET['Email']."'";
// $query       = "insert into User(`Id`, `Password`, `Name`, `PhoneNum`, `Email`) values (".$data_stream.")";

$conn        = mysqli_connect("localhost", "root", "0000", "shopping_db");
$data_stream = "'".$_GET['Id']."','".$_GET['Password']."','".$_GET['Name']."','".$_GET['PhoneNum']."','".$_GET['Email']."','".$_GET['Address']."'";
$query       = "insert into user(`user_id`, `user_pw`, `user_name`, `user_phone`, `user_email`,`user_addrs`) values (".$data_stream.")";

$result = mysqli_query($conn, $query);

if ($result) {
	echo "1";

} else {

	echo "-1";
}

mysqli_close($conn);
?>


