<!--banner-->
<div class="banner-top">
	<div class="container">
		<h1>Login</h1>
		<em></em>
		<h2><a href="index.php">Home</a><label>/</label>Login</h2>
	</div>
</div>


<!-- <div class="banner-top">
<div class="container">
<section class="rw-wrappers">

			</section>
			</div>
</div> -->



<?php
require_once 'core/init.php';
include 'includes/head.php';
include 'includes/navigation.php';
include 'includes/headerfull.php';
include 'includes/leftbar.php';

$sql      = "SELECT * FROM products WHERE featured = 1";
$featured = $db->query($sql);
?>
<!--login-->
<div class="container">
		<div class="login">

<?php
session_start();// 세션
if ($_SESSION['id'] == null) {// 로그인 하지 않았다면
	?>
	<center><br><br><br>
																									<form name="login_form" action="login_check.php" method="post">
																									<!--    ID : <input type="text" name="id"><br>
																									   PW:<input type="password" name="pw"><br><br> -->

																						<div class="col-md-6 login-do">
																							<div class="login-mail">
																								<input type="text" placeholder="Id" required="" name="id">
																								<i  class="glyphicon glyphicon-envelope"></i>
																							</div>
																							<div class="login-mail">
																								<input type="password" placeholder="Password" required="" name="pw">
																								<i class="glyphicon glyphicon-lock"></i>
																							</div>
																							   <a class="news-letter " href="#">
																									 <label class="checkbox1"><input type="checkbox" name="checkbox" ><i> </i>Forget Password</label>
																								   </a>
																							<label class="hvr-skew-backward">
																								<input type="submit" value="login">
																							</label>
																						</div>




																									   <!-- <input type="submit" name="login" value="Login"> -->
																									</form>
																									</center>

	<?php
} else {// 로그인 했다면
	echo "<center><br><br><br>";
	echo $_SESSION['name']."(".$_SESSION['id'].")님이 로그인 하였습니다.";
	echo "&nbsp;<a href='logout.php'><input type='button' value='Logout'></a>";
	echo "</center>";
}

?>
<form>
			<!-- <div class="col-md-6 login-do">
				<div class="login-mail">
					<input type="text" placeholder="Email" required="">
					<i  class="glyphicon glyphicon-envelope"></i>
				</div>
				<div class="login-mail">
					<input type="password" placeholder="Password" required="">
					<i class="glyphicon glyphicon-lock"></i>
				</div>
				   <a class="news-letter " href="#">
						 <label class="checkbox1"><input type="checkbox" name="checkbox" ><i> </i>Forget Password</label>
					   </a>
				<label class="hvr-skew-backward">
					<input type="submit" value="login">
				</label>
			</div> -->
			<div class="col-md-6 login-right">
				 <h3>Completely Free Account</h3>

				 <p>Pellentesque neque leo, dictum sit amet accumsan non, dignissim ac mauris. Mauris rhoncus, lectus tincidunt tempus aliquam, odio
				 libero tincidunt metus, sed euismod elit enim ut mi. Nulla porttitor et dolor sed condimentum. Praesent porttitor lorem dui, in pulvinar enim rhoncus vitae. Curabitur tincidunt, turpis ac lobortis hendrerit, ex elit vestibulum est, at faucibus erat ligula non neque.</p>
				<a href="register.html" class=" hvr-skew-backward">Register</a>

			</div>

			<div class="clearfix"> </div>
			</form>
		</div>

</div>

<!--//login-->





















<?php
include 'includes/rightbar.php';
include 'includes/footer.php';
?>
