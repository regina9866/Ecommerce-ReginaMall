# PHP Ecommerce | By Curtis Parham
An ecommerce web project using PHP, MySQL and Bootstrap by *Curtis Parham*.
Wanna see his youtube playlist? Click [me](https://www.youtube.com/playlist?list=PLFPkAJFH7I0mitTSKDaoxwfLLf-wNNnVS).

#### Setup Database
1. Go to localhost/phpmyadmin and create a database;
2. Name it "ecommerce_db" and set collation to "utf8_unicode_ci";
3. Go to localhost/phpmyadmin and click "ecommerce_db";
4. At the navigation menu, click "Import" and upload the ecommerce_db.sql file in the same folder;

#### How to Navigate in Admin
1. In the browser's address bar, type localhost/ecommerce/admin/;
